"""
predict.py
Load the saved model and predict outcome for a new student.
"""

import pickle
import numpy as np

def predict_student(
    gender: str,
    parent_education: str,
    internet_access: int,
    study_hours_per_day: float,
    attendance_percentage: float,
    previous_score: float,
    sleep_hours: float,
    tutoring_sessions: int,
    extra_curricular: int
):
    """
    Parameters
    ----------
    gender               : 'Male' or 'Female'
    parent_education     : 'None', 'HighSchool', 'Bachelor', 'Master'
    internet_access      : 1 = Yes, 0 = No
    study_hours_per_day  : float (1–10)
    attendance_percentage: float (0–100)
    previous_score       : float (0–100)
    sleep_hours          : float (4–10)
    tutoring_sessions    : 1 = Yes, 0 = No
    extra_curricular     : 1 = Yes, 0 = No
    """
    with open('models/best_model.pkl', 'rb') as f:
        bundle = pickle.load(f)

    model  = bundle['model']
    scaler = bundle['scaler']
    le     = bundle['label_encoder']

    gender_map = {'Male': 1, 'Female': 0}
    edu_map    = {'None': 2, 'HighSchool': 3, 'Bachelor': 0, 'Master': 1}

    features = np.array([[
        gender_map.get(gender, 0),
        edu_map.get(parent_education, 0),
        internet_access,
        study_hours_per_day,
        attendance_percentage,
        previous_score,
        sleep_hours,
        tutoring_sessions,
        extra_curricular
    ]])

    features_sc = scaler.transform(features)
    prediction  = model.predict(features_sc)[0]
    probability = model.predict_proba(features_sc)[0]

    label = le.inverse_transform([prediction])[0]
    conf  = probability[prediction]

    return label, conf


if __name__ == '__main__':
    print("=" * 45)
    print("  Student Performance Prediction Demo")
    print("=" * 45)

    # Example 1 — likely Pass
    result, confidence = predict_student(
        gender='Female',
        parent_education='Bachelor',
        internet_access=1,
        study_hours_per_day=7.5,
        attendance_percentage=90,
        previous_score=78,
        sleep_hours=7,
        tutoring_sessions=1,
        extra_curricular=1
    )
    print(f"\nStudent A → {result}  (confidence: {confidence:.1%})")

    # Example 2 — likely Fail
    result2, conf2 = predict_student(
        gender='Male',
        parent_education='None',
        internet_access=0,
        study_hours_per_day=2,
        attendance_percentage=55,
        previous_score=40,
        sleep_hours=5,
        tutoring_sessions=0,
        extra_curricular=0
    )
    print(f"Student B → {result2}  (confidence: {conf2:.1%})")
    print()
