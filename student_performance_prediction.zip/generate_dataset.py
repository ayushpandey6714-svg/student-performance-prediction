"""
generate_dataset.py
Generates a synthetic student performance dataset and saves it as CSV.
"""

import pandas as pd
import numpy as np

np.random.seed(42)

N = 1000

study_hours     = np.random.uniform(1, 10, N)
attendance      = np.random.uniform(40, 100, N)
prev_score      = np.random.uniform(30, 100, N)
sleep_hours     = np.random.uniform(4, 10, N)
tutoring        = np.random.choice([0, 1], N, p=[0.6, 0.4])
parent_edu      = np.random.choice(['None', 'HighSchool', 'Bachelor', 'Master'], N)
internet        = np.random.choice([0, 1], N, p=[0.3, 0.7])
gender          = np.random.choice(['Male', 'Female'], N)
extra_curricular = np.random.choice([0, 1], N, p=[0.5, 0.5])

edu_map = {'None': 0, 'HighSchool': 1, 'Bachelor': 2, 'Master': 3}
edu_num = np.array([edu_map[e] for e in parent_edu])

# Score formula (deterministic base + noise)
score = (
    study_hours * 3.5
    + attendance * 0.25
    + prev_score * 0.30
    + sleep_hours * 1.2
    + tutoring * 5
    + edu_num * 2
    + internet * 3
    + np.random.normal(0, 5, N)
)
score = np.clip(score, 0, 100)

# Pass/Fail label (threshold = 50)
result = np.where(score >= 50, 'Pass', 'Fail')

df = pd.DataFrame({
    'gender': gender,
    'parent_education': parent_edu,
    'internet_access': internet,
    'study_hours_per_day': study_hours.round(2),
    'attendance_percentage': attendance.round(2),
    'previous_score': prev_score.round(2),
    'sleep_hours': sleep_hours.round(2),
    'tutoring_sessions': tutoring,
    'extra_curricular': extra_curricular,
    'final_score': score.round(2),
    'result': result
})

df.to_csv('data/student_data.csv', index=False)
print(f"Dataset saved: {len(df)} rows")
print(df.head())
