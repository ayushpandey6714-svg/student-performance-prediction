"""
train_model.py
Trains and evaluates multiple ML models for student performance prediction.
Saves the best model and outputs charts to the results/ folder.
"""

import os, warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (
    accuracy_score, classification_report,
    confusion_matrix, ConfusionMatrixDisplay
)
import pickle

# ── Paths ──────────────────────────────────────────────────────────────────────
os.makedirs('data',    exist_ok=True)
os.makedirs('results', exist_ok=True)
os.makedirs('models',  exist_ok=True)

# ── 1. Load data ───────────────────────────────────────────────────────────────
df = pd.read_csv('data/student_data.csv')
print("=" * 60)
print("STUDENT PERFORMANCE PREDICTION")
print("=" * 60)
print(f"\nDataset shape : {df.shape}")
print(f"Pass / Fail   : {df['result'].value_counts().to_dict()}\n")

# ── 2. EDA charts ──────────────────────────────────────────────────────────────
fig, axes = plt.subplots(2, 3, figsize=(16, 10))
fig.suptitle('Exploratory Data Analysis', fontsize=16, fontweight='bold')

# Final score distribution
axes[0,0].hist(df['final_score'], bins=30, color='steelblue', edgecolor='white')
axes[0,0].set_title('Final Score Distribution')
axes[0,0].set_xlabel('Score'); axes[0,0].set_ylabel('Count')

# Study hours vs final score
axes[0,1].scatter(df['study_hours_per_day'], df['final_score'],
                  c=df['result'].map({'Pass':'green','Fail':'red'}),
                  alpha=0.4, s=20)
axes[0,1].set_title('Study Hours vs Final Score')
axes[0,1].set_xlabel('Study Hours/Day'); axes[0,1].set_ylabel('Final Score')

# Pass / Fail count
df['result'].value_counts().plot(kind='bar', ax=axes[0,2],
                                  color=['green','red'], edgecolor='white')
axes[0,2].set_title('Pass vs Fail Count')
axes[0,2].set_xlabel('Result'); axes[0,2].set_ylabel('Count')
axes[0,2].tick_params(axis='x', rotation=0)

# Attendance vs score
axes[1,0].scatter(df['attendance_percentage'], df['final_score'],
                  c=df['result'].map({'Pass':'green','Fail':'red'}),
                  alpha=0.4, s=20)
axes[1,0].set_title('Attendance % vs Final Score')
axes[1,0].set_xlabel('Attendance %'); axes[1,0].set_ylabel('Final Score')

# Previous score vs final score
axes[1,1].scatter(df['previous_score'], df['final_score'],
                  alpha=0.4, s=20, color='purple')
axes[1,1].set_title('Previous Score vs Final Score')
axes[1,1].set_xlabel('Previous Score'); axes[1,1].set_ylabel('Final Score')

# Parent education bar
df.groupby('parent_education')['final_score'].mean().sort_values().plot(
    kind='barh', ax=axes[1,2], color='coral', edgecolor='white')
axes[1,2].set_title('Avg Score by Parent Education')
axes[1,2].set_xlabel('Average Score')

plt.tight_layout()
plt.savefig('results/eda_charts.png', dpi=120)
plt.close()
print("EDA chart saved → results/eda_charts.png")

# ── 3. Pre-processing ──────────────────────────────────────────────────────────
le_gender  = LabelEncoder()
le_edu     = LabelEncoder()
le_result  = LabelEncoder()

df['gender_enc']           = le_gender.fit_transform(df['gender'])
df['parent_education_enc'] = le_edu.fit_transform(df['parent_education'])
df['result_enc']           = le_result.fit_transform(df['result'])   # Fail=0, Pass=1

FEATURES = [
    'gender_enc', 'parent_education_enc', 'internet_access',
    'study_hours_per_day', 'attendance_percentage', 'previous_score',
    'sleep_hours', 'tutoring_sessions', 'extra_curricular'
]
TARGET = 'result_enc'

X = df[FEATURES]
y = df[TARGET]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train_sc = scaler.fit_transform(X_train)
X_test_sc  = scaler.transform(X_test)

# ── 4. Train models ────────────────────────────────────────────────────────────
models = {
    'Logistic Regression':  LogisticRegression(max_iter=500, random_state=42),
    'Decision Tree':        DecisionTreeClassifier(max_depth=5, random_state=42),
    'Random Forest':        RandomForestClassifier(n_estimators=100, random_state=42),
    'K-Nearest Neighbors':  KNeighborsClassifier(n_neighbors=7),
}

results = {}
print("\n── Model Comparison ──────────────────────────────────────")
for name, model in models.items():
    model.fit(X_train_sc, y_train)
    y_pred   = model.predict(X_test_sc)
    acc      = accuracy_score(y_test, y_pred)
    cv_score = cross_val_score(model, X_train_sc, y_train, cv=5, scoring='accuracy').mean()
    results[name] = {'model': model, 'accuracy': acc, 'cv_score': cv_score}
    print(f"  {name:<25}  Test Acc: {acc:.4f}  CV Acc: {cv_score:.4f}")

# ── 5. Best model ──────────────────────────────────────────────────────────────
best_name = max(results, key=lambda n: results[n]['accuracy'])
best      = results[best_name]
print(f"\nBest model → {best_name}  (Accuracy: {best['accuracy']:.4f})")

print(f"\nClassification Report ({best_name}):")
y_pred_best = best['model'].predict(X_test_sc)
print(classification_report(y_test, y_pred_best,
                             target_names=le_result.classes_))

# ── 6. Confusion matrix ────────────────────────────────────────────────────────
cm = confusion_matrix(y_test, y_pred_best)
fig, ax = plt.subplots(figsize=(6, 5))
ConfusionMatrixDisplay(cm, display_labels=le_result.classes_).plot(ax=ax, colorbar=False)
ax.set_title(f'Confusion Matrix — {best_name}')
plt.tight_layout()
plt.savefig('results/confusion_matrix.png', dpi=120)
plt.close()
print("Confusion matrix saved → results/confusion_matrix.png")

# ── 7. Model accuracy comparison chart ────────────────────────────────────────
names  = list(results.keys())
accs   = [results[n]['accuracy']  for n in names]
cvs    = [results[n]['cv_score']  for n in names]

x = np.arange(len(names))
fig, ax = plt.subplots(figsize=(10, 5))
bars1 = ax.bar(x - 0.2, accs, 0.38, label='Test Accuracy', color='steelblue')
bars2 = ax.bar(x + 0.2, cvs,  0.38, label='CV Accuracy',   color='coral')
ax.set_xticks(x); ax.set_xticklabels(names, rotation=15, ha='right')
ax.set_ylim(0, 1.1); ax.set_ylabel('Accuracy')
ax.set_title('Model Accuracy Comparison')
ax.legend()
for bar in bars1: ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.01,
                           f'{bar.get_height():.2f}', ha='center', fontsize=9)
for bar in bars2: ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.01,
                           f'{bar.get_height():.2f}', ha='center', fontsize=9)
plt.tight_layout()
plt.savefig('results/model_comparison.png', dpi=120)
plt.close()
print("Model comparison chart saved → results/model_comparison.png")

# ── 8. Feature importance (Random Forest) ─────────────────────────────────────
rf = results['Random Forest']['model']
importance = pd.Series(rf.feature_importances_, index=FEATURES).sort_values()
fig, ax = plt.subplots(figsize=(8, 5))
importance.plot(kind='barh', ax=ax, color='teal', edgecolor='white')
ax.set_title('Feature Importance (Random Forest)')
ax.set_xlabel('Importance Score')
plt.tight_layout()
plt.savefig('results/feature_importance.png', dpi=120)
plt.close()
print("Feature importance chart saved → results/feature_importance.png")

# ── 9. Correlation heatmap ─────────────────────────────────────────────────────
num_cols = ['study_hours_per_day', 'attendance_percentage', 'previous_score',
            'sleep_hours', 'final_score']
corr = df[num_cols].corr()
fig, ax = plt.subplots(figsize=(7, 6))
sns.heatmap(corr, annot=True, fmt='.2f', cmap='coolwarm', ax=ax, linewidths=0.5)
ax.set_title('Correlation Heatmap')
plt.tight_layout()
plt.savefig('results/correlation_heatmap.png', dpi=120)
plt.close()
print("Correlation heatmap saved → results/correlation_heatmap.png")

# ── 10. Save best model ────────────────────────────────────────────────────────
with open('models/best_model.pkl', 'wb') as f:
    pickle.dump({'model': best['model'], 'scaler': scaler,
                 'features': FEATURES, 'label_encoder': le_result}, f)
print("\nBest model saved → models/best_model.pkl")
print("\n" + "=" * 60)
print("Training complete!")
print("=" * 60)
